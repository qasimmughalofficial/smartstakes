import React, { useState } from 'react'
import BettingList from '../Components/BettingList/BettingList'

function Match() {
    return (
        <>
            <BettingList />
        </>
    )
}

export default Match
